# eStudium

eStudium. A virtual Research Environment for Historians.

This eXist-db application is a data repository application be be used with the front-end [eStudium](https://gitlab.huma-num.fr/estudium/estudiumdata). This runs the [ausoHNum-library](https://gitlab.huma-num.fr/estudium/ausohnum-library). 

## Getting started

Once you've cloned this repository, you may run ant and build a .xar file to be uploaded to your exist-db server.


## License

AGPL v3 - [GNU Affero General Public License](https://www.gnu.org/licenses/agpl-3.0.html)
